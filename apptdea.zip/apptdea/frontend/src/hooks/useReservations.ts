import { useCallback, useEffect, useState } from "react";
import {
  cancelReservation,
  findAllReservations,
  type Reservation,
} from "../services/ReservationService";

interface UseReservationsResult {
  reservations: Reservation[];
  loading: boolean;
  error: string | null;
  cancel: (id: number) => Promise<void>;
  reload: () => Promise<void>;
}

/** Loads the reservations and exposes actions to reload and cancel them. */
export function useReservations(): UseReservationsResult {
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const reload = useCallback(async () => {
    try {
      setError(null);
      setReservations(await findAllReservations());
    } catch {
      setError("No se pudieron cargar las reservas. ¿Está corriendo el backend?");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void reload();
  }, [reload]);

  const cancel = useCallback(
    async (id: number) => {
      try {
        setError(null);
        await cancelReservation(id);
        await reload();
      } catch {
        setError("No se pudo cancelar la reserva.");
      }
    },
    [reload],
  );

  return { reservations, loading, error, cancel, reload };
}