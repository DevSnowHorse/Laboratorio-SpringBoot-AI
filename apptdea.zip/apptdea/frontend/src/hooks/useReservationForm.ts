import { useState } from "react";
import type { ChangeEvent, FormEvent } from "react";
import axios from "axios";
import {
  createReservation,
  type CreateReservationRequest,
} from "../services/ReservationService";

export const AVAILABLE_SERVICES = [
  "Capacitación",
  "Asesoría",
  "Consulta general",
  "Mantenimiento",
  "Evaluación",
];

const EMPTY_FORM: CreateReservationRequest = {
  customerName: "",
  reservationDate: "",
  reservationTime: "",
  serviceName: "",
};

interface UseReservationFormResult {
  values: CreateReservationRequest;
  isValid: boolean;
  submitting: boolean;
  errorMessage: string | null;
  handleChange: (
    event: ChangeEvent<HTMLInputElement | HTMLSelectElement>,
  ) => void;
  handleSubmit: (event: FormEvent<HTMLFormElement>) => Promise<void>;
  dismissError: () => void;
}

/** Extracts a readable message from a failed backend call. */
function extractErrorMessage(error: unknown): string {
  if (axios.isAxiosError(error)) {
    const detail = error.response?.data?.detail;
    if (typeof detail === "string") {
      return detail;
    }
    if (!error.response) {
      return "No se pudo conectar con el servidor.";
    }
  }
  return "No se pudo crear la reserva.";
}

/**
 * Manages the state, validation and submission of the reservation form.
 *
 * @param onCreated callback executed after a reservation is saved successfully
 */
export function useReservationForm(
  onCreated: () => Promise<void> | void,
): UseReservationFormResult {
  const [values, setValues] = useState<CreateReservationRequest>(EMPTY_FORM);
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const isValid = Object.values(values).every((value) => value.trim() !== "");

  function handleChange(
    event: ChangeEvent<HTMLInputElement | HTMLSelectElement>,
  ): void {
    const { name, value } = event.target;
    setValues((current) => ({ ...current, [name]: value }));
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>): Promise<void> {
    event.preventDefault();
    if (!isValid || submitting) {
      return;
    }
    setSubmitting(true);
    try {
      await createReservation(values);
      setValues(EMPTY_FORM);
      await onCreated();
    } catch (error) {
      setErrorMessage(extractErrorMessage(error));
    } finally {
      setSubmitting(false);
    }
  }

  function dismissError(): void {
    setErrorMessage(null);
  }

  return {
    values,
    isValid,
    submitting,
    errorMessage,
    handleChange,
    handleSubmit,
    dismissError,
  };
}