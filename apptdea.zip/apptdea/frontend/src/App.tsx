import { ReservationForm } from "./components/ReservationForm";
import { ReservationTable } from "./components/ReservationTable";
import { useReservations } from "./hooks/useReservations";

function App() {
  const { reservations, loading, error, cancel, reload } = useReservations();

  return (
    <main>
      <ReservationForm onCreated={reload} />
      <ReservationTable
        reservations={reservations}
        loading={loading}
        error={error}
        onCancel={cancel}
      />
    </main>
  );
}

export default App;