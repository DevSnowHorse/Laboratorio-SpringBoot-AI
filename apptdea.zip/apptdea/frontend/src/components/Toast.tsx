import { useEffect } from "react";
import "./Toast.css";

interface ToastProps {
  message: string;
  onClose: () => void;
}

/** Floating error message that closes itself after a few seconds. */
export function Toast({ message, onClose }: ToastProps) {
  useEffect(() => {
    const timer = window.setTimeout(onClose, 5000);
    return () => window.clearTimeout(timer);
  }, [message, onClose]);

  return (
    <div className="toast" role="alert">
      <span>{message}</span>
      <button type="button" aria-label="Cerrar" onClick={onClose}>
        ×
      </button>
    </div>
  );
}