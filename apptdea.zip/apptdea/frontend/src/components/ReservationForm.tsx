import {
    AVAILABLE_SERVICES,
    useReservationForm,
  } from "../hooks/useReservationForm";
  import { Toast } from "./Toast";
  import "./ReservationForm.css";
  
  interface ReservationFormProps {
    onCreated: () => Promise<void> | void;
  }
  
  /** Form to create a reservation; every field is required. */
  export function ReservationForm({ onCreated }: ReservationFormProps) {
    const {
      values,
      isValid,
      submitting,
      errorMessage,
      handleChange,
      handleSubmit,
      dismissError,
    } = useReservationForm(onCreated);
  
    return (
      <section className="reservation-form">
        <h2>Nueva reserva</h2>
        <p className="reservation-form__subtitle">
          Completa todos los campos para agendar una reserva.
        </p>
  
        <form onSubmit={(event) => void handleSubmit(event)}>
          <label className="field field--full">
            Nombre del cliente
            <input
              type="text"
              name="customerName"
              value={values.customerName}
              onChange={handleChange}
              required
            />
          </label>
  
          <label className="field">
            Fecha
            <input
              type="date"
              name="reservationDate"
              value={values.reservationDate}
              onChange={handleChange}
              required
            />
          </label>
  
          <label className="field">
            Hora
            <input
              type="time"
              name="reservationTime"
              value={values.reservationTime}
              onChange={handleChange}
              required
            />
          </label>
  
          <label className="field field--full">
            Servicio
            <select
              name="serviceName"
              value={values.serviceName}
              onChange={handleChange}
              required
            >
              <option value="">Seleccione un servicio</option>
              {AVAILABLE_SERVICES.map((service) => (
                <option key={service} value={service}>
                  {service}
                </option>
              ))}
            </select>
          </label>
  
          <button type="submit" disabled={!isValid || submitting}>
            {submitting ? "Guardando..." : "Crear reserva"}
          </button>
        </form>
  
        {errorMessage && <Toast message={errorMessage} onClose={dismissError} />}
      </section>
    );
  }