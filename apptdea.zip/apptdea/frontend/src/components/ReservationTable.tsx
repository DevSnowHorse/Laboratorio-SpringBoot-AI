import type { Reservation } from "../services/ReservationService";
import "./ReservationTable.css";

interface ReservationTableProps {
  reservations: Reservation[];
  loading: boolean;
  error: string | null;
  onCancel: (id: number) => Promise<void>;
}

/** Table with every reservation and a button to cancel the active ones. */
export function ReservationTable({
  reservations,
  loading,
  error,
  onCancel,
}: ReservationTableProps) {
  return (
    <section className="reservation-table">
      <h2>Reservas</h2>
      <p className="reservation-table__subtitle">
        Listado de reservas obtenidas desde el backend.
      </p>
      {error && <p className="reservation-table__error">{error}</p>}
      {loading ? (
        <p>Cargando...</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Cliente</th>
              <th>Fecha</th>
              <th>Hora</th>
              <th>Servicio</th>
              <th>Estado</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {reservations.length === 0 && (
              <tr>
                <td colSpan={7}>No hay reservas todavía.</td>
              </tr>
            )}
            {reservations.map((reservation) => (
              <tr key={reservation.id}>
                <td>{reservation.id}</td>
                <td>{reservation.customerName}</td>
                <td>{reservation.reservationDate}</td>
                <td>{reservation.reservationTime}</td>
                <td>{reservation.serviceName}</td>
                <td>
                  <span
                    className={`badge badge--${reservation.status.toLowerCase()}`}
                  >
                    {reservation.status}
                  </span>
                </td>
                <td>
                  <button
                    type="button"
                    disabled={reservation.status === "CANCELLED"}
                    onClick={() => void onCancel(reservation.id)}
                  >
                    Cancelar
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </section>
  );
}