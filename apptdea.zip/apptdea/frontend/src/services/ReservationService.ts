import axios from "axios";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL as string;

export type ReservationStatus = "ACTIVE" | "CANCELLED";

export interface Reservation {
  id: number;
  customerName: string;
  reservationDate: string;
  reservationTime: string;
  serviceName: string;
  status: ReservationStatus;
}

export interface CreateReservationRequest {
  customerName: string;
  reservationDate: string;
  reservationTime: string;
  serviceName: string;
}

const client = axios.create({ baseURL: API_BASE_URL });

/** Fetches every reservation from the backend. */
export async function findAllReservations(): Promise<Reservation[]> {
  const response = await client.get<Reservation[]>("/reservas");
  return response.data;
}

/** Creates a reservation and returns the persisted one. */
export async function createReservation(
  request: CreateReservationRequest,
): Promise<Reservation> {
  const response = await client.post<Reservation>("/reservas", request);
  return response.data;
}

/** Cancels the reservation with the given id. */
export async function cancelReservation(id: number): Promise<void> {
  await client.delete(`/reservas/${id}`);
}