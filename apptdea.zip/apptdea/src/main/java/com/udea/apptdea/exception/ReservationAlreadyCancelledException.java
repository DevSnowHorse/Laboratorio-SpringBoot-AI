package com.udea.apptdea.exception;

/**
 * Thrown when a cancel operation targets a reservation that is already cancelled.
 */
public final class ReservationAlreadyCancelledException extends BusinessException {

    /**
     * Creates the exception for a reservation that is already cancelled.
     *
     * @param id reservation identifier
     */
    public ReservationAlreadyCancelledException(Long id) {
        super("Reservation is already cancelled: %s".formatted(id));
    }
}
