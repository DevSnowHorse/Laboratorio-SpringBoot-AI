package com.udea.apptdea.config;

import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

/**
 * Registers a CORS filter that accepts browser requests from the frontend origin.
 */
@Configuration
public class CorsFilterConfiguration {

    private static final String FRONTEND_ORIGIN = "http://localhost:3000";

    /**
     * Builds a {@link CorsFilter} applied to every path.
     *
     * @return CORS filter allowing {@code http://localhost:3000} with any method and header
     */
    @Bean
    public CorsFilter corsFilter() {
        var configuration = new CorsConfiguration();
        configuration.setAllowedOrigins(List.of(FRONTEND_ORIGIN));
        configuration.setAllowedMethods(List.of("*"));
        configuration.setAllowedHeaders(List.of("*"));
        configuration.setExposedHeaders(List.of("Location"));
        configuration.setAllowCredentials(true);

        var source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return new CorsFilter(source);
    }
}
