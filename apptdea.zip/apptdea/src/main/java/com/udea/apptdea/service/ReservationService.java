package com.udea.apptdea.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.udea.apptdea.entity.Reservation;
import com.udea.apptdea.entity.ReservationStatus;
import com.udea.apptdea.exception.DuplicateReservationException;
import com.udea.apptdea.exception.ReservationAlreadyCancelledException;
import com.udea.apptdea.exception.ReservationNotFoundException;
import com.udea.apptdea.repository.ReservationRepository;

/**
 * Application service that implements reservation business rules.
 */
@Service
public class ReservationService {

    private final ReservationRepository reservationRepository;

    /**
     * Creates the service with its persistence dependency.
     *
     * @param reservationRepository repository used to load and store reservations
     */
    public ReservationService(ReservationRepository reservationRepository) {
        this.reservationRepository = reservationRepository;
    }

    /**
     * Returns every persisted reservation.
     *
     * @return all reservations, possibly empty
     */
    @Transactional(readOnly = true)
    public List<Reservation> findAll() {
        return reservationRepository.findAll();
    }

    /**
     * Creates a reservation when the requested date and time are free.
     *
     * @param reservation reservation to persist; status is set to {@link ReservationStatus#ACTIVE}
     * @return the persisted reservation
     * @throws DuplicateReservationException if another reservation already exists for the same date and time
     */
    @Transactional
    public Reservation create(Reservation reservation) {
        var reservationDate = reservation.getReservationDate();
        var reservationTime = reservation.getReservationTime();
        if (reservationRepository.existsByReservationDateAndReservationTime(reservationDate, reservationTime)) {
            throw new DuplicateReservationException(reservationDate, reservationTime);
        }
        reservation.setStatus(ReservationStatus.ACTIVE);
        return reservationRepository.save(reservation);
    }

    /**
     * Cancels the reservation identified by {@code id}.
     *
     * @param id reservation identifier
     * @return the updated reservation with status {@link ReservationStatus#CANCELLED}
     * @throws ReservationNotFoundException if no reservation exists for {@code id}
     * @throws ReservationAlreadyCancelledException if the reservation is already cancelled
     */
    @Transactional
    public Reservation cancel(Long id) {
        var reservation = reservationRepository.findById(id)
                .orElseThrow(() -> new ReservationNotFoundException(id));
        if (reservation.getStatus() == ReservationStatus.CANCELLED) {
            throw new ReservationAlreadyCancelledException(id);
        }
        reservation.setStatus(ReservationStatus.CANCELLED);
        return reservationRepository.save(reservation);
    }
}
