package com.udea.apptdea.controller;

import java.net.URI;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.udea.apptdea.dto.CreateReservationRequest;
import com.udea.apptdea.dto.ReservationResponse;
import com.udea.apptdea.entity.Reservation;
import com.udea.apptdea.service.ReservationService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * REST controller for reservation resources.
 */
@RestController
@RequestMapping("/reservas")
@Tag(name = "Reservations", description = "Create, list and cancel reservations")
public class ReservationController {

    private final ReservationService reservationService;

    /**
     * Creates the controller with its application service.
     *
     * @param reservationService reservation use cases
     */
    public ReservationController(ReservationService reservationService) {
        this.reservationService = reservationService;
    }

    /**
     * Lists every reservation.
     *
     * @return {@code 200 OK} with the reservation collection, which may be empty
     */
    @GetMapping
    @Operation(summary = "List all reservations")
    public ResponseEntity<List<ReservationResponse>> findAll() {
        var responses = reservationService.findAll().stream().map(this::toResponse).toList();
        return ResponseEntity.ok(responses);
    }

    /**
     * Creates a reservation when the date and time are available.
     *
     * @param request reservation data
     * @return {@code 201 Created} with the persisted reservation
     */
    @PostMapping
    @Operation(summary = "Create a reservation")
    public ResponseEntity<ReservationResponse> create(@RequestBody CreateReservationRequest request) {
        var created = reservationService.create(toEntity(request));
        var body = toResponse(created);
        return ResponseEntity.created(URI.create("/reservas/" + created.getId())).body(body);
    }

    /**
     * Cancels the reservation identified by {@code id}.
     *
     * @param id reservation identifier
     * @return {@code 204 No Content} when cancellation succeeds
     */
    @DeleteMapping("/{id}")
    @Operation(summary = "Cancel a reservation")
    public ResponseEntity<Void> cancel(@PathVariable Long id) {
        reservationService.cancel(id);
        return ResponseEntity.noContent().build();
    }

    private Reservation toEntity(CreateReservationRequest request) {
        return new Reservation(
                request.customerName(),
                request.reservationDate(),
                request.reservationTime(),
                request.serviceName(),
                null);
    }

    private ReservationResponse toResponse(Reservation reservation) {
        return new ReservationResponse(
                reservation.getId(),
                reservation.getCustomerName(),
                reservation.getReservationDate(),
                reservation.getReservationTime(),
                reservation.getServiceName(),
                reservation.getStatus());
    }
}
