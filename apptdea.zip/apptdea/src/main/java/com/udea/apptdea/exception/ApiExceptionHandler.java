package com.udea.apptdea.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * Maps domain exceptions to HTTP status codes for the REST API.
 */
@RestControllerAdvice
public class ApiExceptionHandler {

    /**
     * Returns {@code 404 Not Found} when the reservation does not exist.
     *
     * @param exception missing reservation
     * @return problem details with status 404
     */
    @ExceptionHandler(ReservationNotFoundException.class)
    public ResponseEntity<ProblemDetail> handleNotFound(ReservationNotFoundException exception) {
        return problem(HttpStatus.NOT_FOUND, exception.getMessage());
    }

    /**
     * Returns {@code 409 Conflict} when the requested slot is already booked.
     *
     * @param exception duplicate reservation
     * @return problem details with status 409
     */
    @ExceptionHandler(DuplicateReservationException.class)
    public ResponseEntity<ProblemDetail> handleDuplicate(DuplicateReservationException exception) {
        return problem(HttpStatus.CONFLICT, exception.getMessage());
    }

    /**
     * Returns {@code 409 Conflict} when the reservation is already cancelled.
     *
     * @param exception already cancelled reservation
     * @return problem details with status 409
     */
    @ExceptionHandler(ReservationAlreadyCancelledException.class)
    public ResponseEntity<ProblemDetail> handleAlreadyCancelled(ReservationAlreadyCancelledException exception) {
        return problem(HttpStatus.CONFLICT, exception.getMessage());
    }

    /**
     * Returns {@code 400 Bad Request} when the payload fails validation.
     *
     * @param exception invalid argument from a DTO or request
     * @return problem details with status 400
     */
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ProblemDetail> handleInvalidArgument(IllegalArgumentException exception) {
        return problem(HttpStatus.BAD_REQUEST, exception.getMessage());
    }

    private static ResponseEntity<ProblemDetail> problem(HttpStatus status, String detail) {
        return ResponseEntity.status(status).body(ProblemDetail.forStatusAndDetail(status, detail));
    }
}
