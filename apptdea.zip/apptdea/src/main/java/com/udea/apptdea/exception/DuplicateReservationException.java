package com.udea.apptdea.exception;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 * Thrown when a reservation is requested for a date and time that are already booked.
 */
public final class DuplicateReservationException extends BusinessException {

    /**
     * Creates the exception for a conflicting date and time.
     *
     * @param reservationDate conflicting date
     * @param reservationTime conflicting time
     */
    public DuplicateReservationException(LocalDate reservationDate, LocalTime reservationTime) {
        super("A reservation already exists for %s at %s".formatted(reservationDate, reservationTime));
    }
}
