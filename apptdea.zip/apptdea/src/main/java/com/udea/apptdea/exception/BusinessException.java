package com.udea.apptdea.exception;

/**
 * Base type for domain rule violations.
 */
public sealed class BusinessException extends RuntimeException
        permits DuplicateReservationException, ReservationNotFoundException,
        ReservationAlreadyCancelledException {

    /**
     * Creates a business exception with the given message.
     *
     * @param message description of the violated rule
     */
    public BusinessException(String message) {
        super(message);
    }
}
