package com.udea.apptdea.exception;

/**
 * Thrown when a reservation id does not match any persisted reservation.
 */
public final class ReservationNotFoundException extends BusinessException {

    /**
     * Creates the exception for a missing reservation.
     *
     * @param id reservation identifier that was not found
     */
    public ReservationNotFoundException(Long id) {
        super("Reservation not found: %s".formatted(id));
    }
}
