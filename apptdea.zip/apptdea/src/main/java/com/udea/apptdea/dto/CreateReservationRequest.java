package com.udea.apptdea.dto;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 * Request body used to create a reservation.
 *
 * @param customerName customer name, must not be blank
 * @param reservationDate reservation date, must not be {@code null}
 * @param reservationTime reservation time, must not be {@code null}
 * @param serviceName booked service name, must not be blank
 */
public record CreateReservationRequest(
        String customerName,
        LocalDate reservationDate,
        LocalTime reservationTime,
        String serviceName) {

    /**
     * Validates that required fields are present.
     */
    public CreateReservationRequest {
        if (customerName == null || customerName.isBlank()) {
            throw new IllegalArgumentException("customerName must not be blank");
        }
        if (reservationDate == null) {
            throw new IllegalArgumentException("reservationDate must not be null");
        }
        if (reservationTime == null) {
            throw new IllegalArgumentException("reservationTime must not be null");
        }
        if (serviceName == null || serviceName.isBlank()) {
            throw new IllegalArgumentException("serviceName must not be blank");
        }
    }
}
