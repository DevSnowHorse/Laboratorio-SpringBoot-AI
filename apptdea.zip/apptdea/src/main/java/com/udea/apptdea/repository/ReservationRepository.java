package com.udea.apptdea.repository;

import java.time.LocalDate;
import java.time.LocalTime;

import org.springframework.data.jpa.repository.JpaRepository;

import com.udea.apptdea.entity.Reservation;

/**
 * Spring Data JPA repository for {@link Reservation} persistence.
 */
public interface ReservationRepository extends JpaRepository<Reservation, Long> {

    /**
     * Checks whether a reservation already exists for the given date and time.
     *
     * @param reservationDate date to match
     * @param reservationTime time to match
     * @return {@code true} if a reservation exists for that slot, otherwise {@code false}
     */
    boolean existsByReservationDateAndReservationTime(LocalDate reservationDate, LocalTime reservationTime);
}
