package com.udea.apptdea.entity;

/**
 * Lifecycle status of a reservation.
 */
public enum ReservationStatus {

    /**
     * The reservation is currently booked.
     */
    ACTIVE,

    /**
     * The reservation was cancelled.
     */
    CANCELLED
}
