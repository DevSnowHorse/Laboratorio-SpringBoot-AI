package com.udea.apptdea.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.udea.apptdea.entity.Reservation;
import com.udea.apptdea.entity.ReservationStatus;
import com.udea.apptdea.exception.DuplicateReservationException;
import com.udea.apptdea.exception.ReservationNotFoundException;
import com.udea.apptdea.service.ReservationService;

@WebMvcTest(ReservationController.class)
class ReservationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private ReservationService reservationService;

    @Test
    void findAllReturnsOk() throws Exception {
        when(reservationService.findAll()).thenReturn(List.of());
        mockMvc.perform(get("/reservas")).andExpect(status().isOk());
    }

    @Test
    void createReturnsCreated() throws Exception {
        var reservation = new Reservation(1L, "Ana", LocalDate.parse("2026-11-01"), LocalTime.parse("10:00"),
                "Haircut", ReservationStatus.ACTIVE);
        when(reservationService.create(any(Reservation.class))).thenReturn(reservation);

        mockMvc.perform(post("/reservas")
                .contentType(MediaType.APPLICATION_JSON)
                .content("""
                        {
                          "customerName": "Ana",
                          "reservationDate": "2026-11-01",
                          "reservationTime": "10:00",
                          "serviceName": "Haircut"
                        }
                        """))
                .andExpect(status().isCreated())
                .andExpect(header().string("Location", "/reservas/1"));
    }

    @Test
    void createDuplicateReturnsConflict() throws Exception {
        when(reservationService.create(any(Reservation.class)))
                .thenThrow(new DuplicateReservationException(LocalDate.parse("2026-11-01"), LocalTime.parse("10:00")));

        mockMvc.perform(post("/reservas")
                .contentType(MediaType.APPLICATION_JSON)
                .content("""
                        {
                          "customerName": "Ana",
                          "reservationDate": "2026-11-01",
                          "reservationTime": "10:00",
                          "serviceName": "Haircut"
                        }
                        """))
                .andExpect(status().isConflict());
    }

    @Test
    void cancelReturnsNoContent() throws Exception {
        when(reservationService.cancel(1L)).thenReturn(
                new Reservation(1L, "Ana", LocalDate.parse("2026-11-01"), LocalTime.parse("10:00"),
                        "Haircut", ReservationStatus.CANCELLED));
        mockMvc.perform(delete("/reservas/1")).andExpect(status().isNoContent());
    }

    @Test
    void cancelMissingReturnsNotFound() throws Exception {
        when(reservationService.cancel(99L)).thenThrow(new ReservationNotFoundException(99L));
        mockMvc.perform(delete("/reservas/99")).andExpect(status().isNotFound());
    }
}
